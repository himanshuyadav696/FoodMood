package com.example.androidTemplate.utils.lang

interface OnLocaleChangedListener {
    fun onBeforeLocaleChanged()

    fun onAfterLocaleChanged()
}
