package com.example.androidTemplate.core.exception

import java.io.IOException

class NoConnectionException : IOException("Not Connected")
