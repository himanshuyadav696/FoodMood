package com.example.androidTemplate.ui.login
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.FragmentOtpBinding

class OtpFragment : Fragment() {
    private lateinit var binding: FragmentOtpBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentOtpBinding.inflate(inflater)
        binding.lifecycleOwner = this
        binding.btnBack.setOnClickListener {
            it.findNavController().popBackStack()
        }
        val edit =
            arrayOf<EditText>(binding.otpEditBox1, binding.otpEditBox2, binding.otpEditBox3, binding.otpEditBox4)

        binding.otpEditBox1.addTextChangedListener(GenericTextWatcher(binding.otpEditBox1, edit))
        binding.otpEditBox2.addTextChangedListener(GenericTextWatcher(binding.otpEditBox2, edit))
        binding.otpEditBox3.addTextChangedListener(GenericTextWatcher(binding.otpEditBox3, edit))
        binding.otpEditBox4.addTextChangedListener(GenericTextWatcher(binding.otpEditBox4, edit))

        binding.btnVerify.setOnClickListener {
            findNavController().navigate(OtpFragmentDirections.actionOtpFragmentToResetPasswordFragment())
        }

        return binding.root
    }

    class GenericTextWatcher(private val view: View, private val editText: Array<EditText>) :
        TextWatcher {
        override fun afterTextChanged(editable: Editable) {
            val text = editable.toString()
            when (view.id) {
                R.id.otp_edit_box1 -> if (text.length == 1) editText[1].requestFocus()
                R.id.otp_edit_box2 -> if (text.length == 1) editText[2].requestFocus() else if (text.isEmpty()) editText[0].requestFocus()
                R.id.otp_edit_box3 -> if (text.length == 1) editText[3].requestFocus() else if (text.isEmpty()) editText[1].requestFocus()
                R.id.otp_edit_box4 -> if (text.isEmpty()) editText[2].requestFocus()
            }
        }
        override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}
        override fun onTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}
    }
}