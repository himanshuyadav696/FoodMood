package com.example.androidTemplate.ui.login

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.FragmentResetPwdSuccessBinding

class ResetPwdSuccessFragment : Fragment() {
    private lateinit var binding:FragmentResetPwdSuccessBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentResetPwdSuccessBinding.inflate(layoutInflater)
        binding.apply {
            btnBack.setOnClickListener {
                startSignInActivity()
            }
            btnGetMoodyAgain.setOnClickListener {
                startSignInActivity()
            }
        }
        return binding.root
    }

    private fun startSignInActivity(){
        val intent = Intent(requireActivity(),SignInActivity::class.java)
        startActivity(intent)
        requireActivity().finish()
    }
}