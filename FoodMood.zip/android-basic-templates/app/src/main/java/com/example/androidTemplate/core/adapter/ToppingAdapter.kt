package com.example.androidTemplate.core.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.CustomisationLayoutBinding
import com.example.androidTemplate.databinding.ToppingLayoutBinding
import com.example.androidTemplate.ui.home.Customisation

class ToppingAdapter(val context: Context) :
    RecyclerView.Adapter<ToppingAdapter.ViewHolder>() {
    var resultList: List<Customisation>? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = DataBindingUtil.inflate<ToppingLayoutBinding>(
            layoutInflater,
            R.layout.topping_layout,
            parent,
            false
        )
        return ViewHolder(binding)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(resultList!![position], position)

    }

    override fun getItemCount(): Int {
        if(resultList==null){
            return 0
        }else{
            return resultList!!.size
        }
    }

    inner class ViewHolder(val binding: ToppingLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(model: Customisation?, position: Int) {
            binding.apply {
                tvFoodName.text = model?.foodName
                tvPrice.text = model?.foodPrice
            }
        }
    }

    fun setData(it: List<Customisation>?) {
        resultList = it
        notifyDataSetChanged()
    }
}