package com.example.androidTemplate.ui.login
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.androidTemplate.databinding.FragmentResetPasswordBinding

class ResetPasswordFragment : Fragment() {
    private lateinit var binding:FragmentResetPasswordBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentResetPasswordBinding.inflate(layoutInflater)
        binding.apply {
            btnBack.setOnClickListener {
                findNavController().popBackStack()
            }
            btnSubmit.setOnClickListener {
                findNavController().navigate(ResetPasswordFragmentDirections.actionResetPasswordFragmentToResetPwdSuccessFragment())
            }
        }
        return binding.root
    }

}