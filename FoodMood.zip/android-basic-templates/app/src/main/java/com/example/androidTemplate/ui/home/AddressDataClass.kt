package com.example.androidTemplate.ui.home

data class AddressDataClass(val image: Int, val homeName: String,val address:String) {
}
