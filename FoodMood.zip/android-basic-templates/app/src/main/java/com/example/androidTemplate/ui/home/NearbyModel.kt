package com.example.androidTemplate.ui.home

data class NearbyModel(
    val image: Int,
    val restaurantsName: String,
    val food_type:String,
    val foodName:String,
    val foodPrice:String,
    val deliv_time:String
)

