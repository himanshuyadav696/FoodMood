package com.example.sampleproject.data.network

import com.google.firebase.auth.*

class FirebaseRepo(private val auth: FirebaseAuth) {
/*
    private var verificationId: String? = null
    var resendToken: PhoneAuthProvider.ForceResendingToken? = null

    suspend fun performPhoneAuth(phone: String, activity: BaseActivity) =
        suspendCoroutine<FirebaseLoginResponse> { continuation ->
            //TODO use executor


            val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    if (credential.smsCode == null) {
                        auth.signInWithCredential(credential).addOnSuccessListener {

                            println("sms code was null")
                            continuation.resume(FirebaseLoginResponse(it))

                        }.addOnFailureListener {
                            AppUtils.toastMessgae(
                                activity,
                                "" + it.message,
                                Toast.LENGTH_SHORT
                            )
                            continuation.resumeWithException(it)
                        }
                    }
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    if (e is FirebaseAuthInvalidCredentialsException) {
                        println("onVerificationFailed: $e")
                        continuation.resumeWithException(e)

                    } else if (e is FirebaseTooManyRequestsException) {
                        println("onVerificationFailed:$e")
                        AppUtils.toastMessgae(
                            activity,
                            activity.resources.getString(R.string.exceed_otp),
                            Toast.LENGTH_SHORT
                        )
                        continuation.resumeWithException(e)
                    } else {
                        AppUtils.toastMessgae(
                            activity,
                            "" + e.message,
                            Toast.LENGTH_SHORT)
                        continuation.resumeWithException(e)
                    }
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    println("onCodeSent:code is sent ")

                    continuation.resume(FirebaseLoginResponse(isCodeSend = true))
                    resendToken = token
                    this@FirebaseRepo.verificationId = verificationId
                    AppUtils.toastMessgae(
                        activity,
                        activity.resources.getString(R.string.otp_sent),
                        Toast.LENGTH_SHORT
                    )
                }
            }

            //todo simplify
            resendToken?.let {
                PhoneAuthOptions.newBuilder(auth)
                    .setPhoneNumber(phone)       // Phone number to verify
                    .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                    .setActivity(activity)                 // Activity (for callback binding)
                    .setCallbacks(callbacks)
                    .setForceResendingToken(it)
                    .build()?.apply {
                        PhoneAuthProvider.verifyPhoneNumber(this)
                    }
            } ?: {
                PhoneAuthOptions.newBuilder(auth)
                    .setPhoneNumber(phone)       // Phone number to verify
                    .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                    .setActivity(activity)                 // Activity (for callback binding)
                    .setCallbacks(callbacks)
                    .build()?.apply { PhoneAuthProvider.verifyPhoneNumber(this) }
            }.invoke()
        }


    suspend fun verifyOtp(otp: String) = suspendCoroutine<FirebaseLoginResponse> { continuation ->
        verificationId?.let {
            auth.signInWithCredential(
                PhoneAuthProvider.getCredential(it, otp)
            ).addOnSuccessListener {
                println("verifyOtp:success ")
                continuation.resume(FirebaseLoginResponse(it))
            }.addOnFailureListener {
                continuation.resumeWithException(it)
            }
        } ?: {
            continuation.resumeWithException(Throwable(message = "null verification id"))
        }.invoke()
    }

    suspend fun getIdToken() = suspendCoroutine<String?> { continuation ->
        auth.currentUser?.getIdToken(true)?.addOnSuccessListener {
            println("verifyOtp:success ")
            continuation.resume(it.token)
        }?.addOnFailureListener {
            continuation.resumeWithException(it)
        }
    }*/
}