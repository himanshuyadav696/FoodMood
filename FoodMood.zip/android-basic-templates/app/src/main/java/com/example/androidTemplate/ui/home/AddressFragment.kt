package com.example.androidTemplate.ui.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.androidTemplate.R
import com.example.androidTemplate.core.adapter.NearbyAdapter
import com.example.androidTemplate.core.adapter.SavedAddressAdapter
import com.example.androidTemplate.databinding.FragmentAddressBinding

class AddressFragment : Fragment() {
    private lateinit var binding:FragmentAddressBinding
    private lateinit var savedAddressAdapter:SavedAddressAdapter
    private val addressList = mutableListOf<AddressDataClass>()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAddressBinding.inflate(layoutInflater)
        rcvSavedAddress()
        return binding.root
    }
    private fun rcvSavedAddress() {
        binding.rcvSavedAddress.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)
        savedAddressAdapter = SavedAddressAdapter(requireContext())
        binding.rcvSavedAddress.adapter = savedAddressAdapter
        for (i in 1..5) {
            addressList.add(AddressDataClass(R.drawable.ic_home,"Home$i","Pragati Vihar Khora Colony$i"))
        }
        savedAddressAdapter.setData(addressList)
    }
}