package com.example.androidTemplate.core.adapter
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.SavedAddressLayoutBinding
import com.example.androidTemplate.ui.home.AddressDataClass

class SavedAddressAdapter(val context: Context) :
    RecyclerView.Adapter<SavedAddressAdapter.ViewHolder>() {
    var resultList: List<AddressDataClass>? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = DataBindingUtil.inflate<SavedAddressLayoutBinding>(
            layoutInflater,
            R.layout.saved_address_layout,
            parent,
            false
        )
        return ViewHolder(binding)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(resultList!![position], position)

    }

    override fun getItemCount(): Int {
        if(resultList==null){
            return 0
        }else{
            return resultList!!.size
        }
    }

    inner class ViewHolder(val binding: SavedAddressLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(model: AddressDataClass?, position: Int) {
            binding.apply {
                model?.image?.let { ivHome.setImageResource(it) }
                model?.homeName?.let { tvHomeName.text = it }
                model?.address?.let { tvHomeAddress.text = it }
            }
        }
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    fun setData(it: List<AddressDataClass>?) {
        resultList = it
        notifyDataSetChanged()
    }
}