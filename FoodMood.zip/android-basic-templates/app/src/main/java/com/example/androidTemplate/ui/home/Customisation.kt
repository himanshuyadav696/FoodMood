package com.example.androidTemplate.ui.home

data class Customisation(
    val foodName:String,
    val foodPrice:String
)
