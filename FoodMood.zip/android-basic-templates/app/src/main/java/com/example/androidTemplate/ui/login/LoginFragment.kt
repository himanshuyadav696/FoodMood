package com.example.androidTemplate.ui.login
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.example.androidTemplate.MainActivity
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.FragmentLoginBinding
import com.example.androidTemplate.utils.extensions.makeLinks
class LoginFragment : Fragment() {
    private lateinit var binding: FragmentLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentLoginBinding.inflate(inflater)
        binding.lifecycleOwner = this
        initObservers()
        return binding.root
    }
    private fun initObservers() {
        binding.tvAllReadyAcc.makeLinks(
            Pair(getString(R.string.sign_in), View.OnClickListener {
                it.findNavController()
                    .navigate(LoginFragmentDirections.actionMoveToRegisterFragment())

            }), isUnderLine = false
        )
        binding.btnBack.setOnClickListener {
            requireActivity().finish()
        }
        binding.tvForgotPassword.setOnClickListener {
            findNavController().navigate(LoginFragmentDirections.actionLoginFragmentToForgotPasswordFragment())
        }
        binding.btnSigIn.setOnClickListener {
            val intent = Intent(requireActivity(),MainActivity::class.java)
            startActivity(intent)
            requireActivity().finish()
        }
    }
}