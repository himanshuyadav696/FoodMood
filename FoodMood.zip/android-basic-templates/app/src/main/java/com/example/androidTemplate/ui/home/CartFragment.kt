package com.example.androidTemplate.ui.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.FragmentCartBinding

class CartFragment : Fragment() {
    private lateinit var binding:FragmentCartBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCartBinding.inflate(layoutInflater)
        binding.apply {
            tvMinus.setOnClickListener {
                decreaseInteger()
            }
            tvPlus.setOnClickListener {
                increaseInteger()
            }
            btnCheckout.setOnClickListener {
                findNavController().navigate(CartFragmentDirections.actionCartFragmentToAddressFragment())
            }
        }
        return binding.root
    }

    fun increaseInteger() {
        display(binding.tvCount.text.toString().toInt() + 1)
    }

    fun decreaseInteger() {
        if(binding.tvCount.text.toString().toInt()==0){
            binding.tvCount.text = "0"
        }
        else{
            display(binding.tvCount.text.toString().toInt() - 1)
        }
    }

    private fun display(number: Int) {
        binding.tvCount.text = "$number"
    }

}