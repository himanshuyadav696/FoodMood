package com.example.androidTemplate.ui.home

data class ItemsViewModel(val image: Int, val foodName: String) {
}
