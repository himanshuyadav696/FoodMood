package com.example.androidTemplate.ui.home
import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.androidTemplate.core.adapter.CustomisationAdapter
import com.example.androidTemplate.core.adapter.ToppingAdapter
import com.example.androidTemplate.databinding.FragmentBottomSheetFoodBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import splitties.resources.color
import splitties.resources.drawable

class BottomSheetFoodFragment : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentBottomSheetFoodBinding
    private lateinit var customisationAdapter: CustomisationAdapter
    private lateinit var toppingAdapter: ToppingAdapter
    val customisationList = mutableListOf<Customisation>()
    val topList = mutableListOf<Customisation>()
    val dipList = mutableListOf<Customisation>()
    @SuppressLint("ResourceType")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentBottomSheetFoodBinding.inflate(layoutInflater)
        binding.llclose.setBackgroundColor(Color.TRANSPARENT)
        rcvCustomisation()
        rcvTopping()
        rcvDips()
        return binding.root
    }

    private fun rcvCustomisation() {
        binding.rcvCustomisation.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)
        customisationAdapter = CustomisationAdapter(requireContext())
        binding.rcvCustomisation.adapter = customisationAdapter
        for (i in 1..5) {
            customisationList.add(Customisation("FoodName$i", "₹ 100$i"))
        }
        customisationAdapter.setData(customisationList)
    }

    private fun rcvTopping() {
        binding.rcvTopping.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)
        toppingAdapter = ToppingAdapter(requireContext())
        binding.rcvTopping.adapter = toppingAdapter
        for (i in 1..5) {
            topList.add(Customisation("FoodName$i", "₹ 100$i"))
        }
        toppingAdapter.setData(topList)
    }

    private fun rcvDips() {
        binding.rcvDips.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)
        toppingAdapter = ToppingAdapter(requireContext())
        binding.rcvDips.adapter = toppingAdapter
        for (i in 1..3) {
            dipList.add(Customisation("FoodName$i", "₹ 100$i"))
        }
        toppingAdapter.setData(dipList)
    }
}