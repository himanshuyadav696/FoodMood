package com.example.androidTemplate.ui.login

import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.androidTemplate.MainActivity
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.ActivityOtpBinding
import com.example.androidTemplate.utils.AppConstants
import com.example.androidTemplate.utils.AppUtils
import com.example.androidTemplate.utils.extensions.getColoredString
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import java.util.concurrent.TimeUnit

class OtpActivity : AppCompatActivity() {
    private var countryCode: String? = ""
    private var mobile: String? = ""
    private lateinit var binding: ActivityOtpBinding
    private var mAuth: FirebaseAuth? = null
    private var verificationid: String? = ""
    private var progressDialog: Dialog? = null

    private val mResendToken: PhoneAuthProvider.ForceResendingToken? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@OtpActivity, R.layout.activity_otp)
        countryCode = intent.extras?.getString(AppConstants.COUNTRY_CODE, "")
        mobile = intent.extras?.getString(AppConstants.MOBILE_NUMBER)
        mAuth = FirebaseAuth.getInstance()

        /*  object : CountDownTimer(60000, 1000) {

              override fun onTick(millisUntilFinished: Long) {

                  val seconds = millisUntilFinished / 1000
                  tv_timer.text = "${(seconds / 60)}:${(seconds % 60)}"
              }

              override fun onFinish() {
                  timer = true
                  tv_timer.text = "00:00"
              }
          }.start()*/
        setOtpTitle()
        /*binding.tvResend.setOnClickListener {
            mResendToken?.let {
                val number = countryCode + mobile
                resendVerificationCode(number, it)
            }

        }
        binding.btnLogin.setOnClickListener {
            //validation(binding.pvOtp.text.toString())
        }*/
    }

    private fun setOtpTitle() {
        val mobile = "+917836090028"
        val str = "Please enter the OTP sent on your mobile number\n $mobile"
        val start = str.length - mobile.length
        val end = str.length - 1
        val strr = str.getColoredString(resources.getColor(R.color.colorAccent, null), start, end)
        //binding.tvTitle.text = strr
    }

    private fun showToast(msg: String) {
        Toast.makeText(this@OtpActivity, msg, Toast.LENGTH_SHORT).show()
    }


    fun sendVerificationCode() {
        val number = countryCode + mobile
        val options = PhoneAuthOptions.newBuilder(mAuth!!)
            .setPhoneNumber(number)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this@OtpActivity)
            .setCallbacks(mCallBack)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private val mCallBack = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        override fun onCodeSent(p0: String, p1: PhoneAuthProvider.ForceResendingToken) {
            super.onCodeSent(p0, p1)
            try {
                verificationid = p0

                Toast.makeText(
                    this@OtpActivity,
                    resources.getString(R.string.otp_sent),
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
                Toast.makeText(this@OtpActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        override fun onVerificationCompleted(phoneAuthCredential: PhoneAuthCredential) {
            val code = phoneAuthCredential.smsCode
            try {
                if (code != null) {
                    // binding.pvOtp.value = code
                    // verifyCode(code)
                }
            } catch (e: Exception) {
                Toast.makeText(this@OtpActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        override fun onVerificationFailed(e: FirebaseException) {
            Toast.makeText(this@OtpActivity, e.message, Toast.LENGTH_LONG).show()
            if (progressDialog != null) {
                progressDialog!!.dismiss()
            }
        }
    }


    private fun verifyPhoneNumberWithCode(verificationId: String, code: String) {
        // [START verify_with_code]
        val credential = PhoneAuthProvider.getCredential(verificationId, code)
        getOtpAuth(credential)
        // [END verify_with_code]
    }

    private fun getOtpAuth(credential: PhoneAuthCredential) {
        mAuth!!.signInWithCredential(credential)
            .addOnCompleteListener(this@OtpActivity) { task ->
                if (task.isSuccessful) {
                    val userID = task.result?.user?.uid
                    AppUtils.putPrefBoolean(
                        AppConstants.USER_PREF.IS_LOGIN,
                        true,
                        this@OtpActivity
                    )
                    /*   if (model!!.isLogin) {
                           loginUser()
                       } else {
                           registerUser(userID!!)
                       }
                       if (progressDialog != null) {
                           progressDialog!!.dismiss()
                       }*/

                    /*  AppUtils.setCurrentFragment(
                          activity!!, R.id.containerSignIn,
                          AddPasswordFragment.newInstance(viewModel), AddPasswordFragment.TAG
                      )*/

                } else {
                    if (progressDialog != null) {
                        progressDialog!!.dismiss()
                    }
                    if (task.exception is FirebaseAuthInvalidCredentialsException) {
                        Toast.makeText(
                            this@OtpActivity,
                            "Error: ${task.exception}",
                            Toast.LENGTH_LONG
                        )
                            .show()
                    }
                }
            }


    }

    private fun loginUser() {
        if (progressDialog != null) {
            progressDialog!!.dismiss()
        }
        startActivity(Intent(this@OtpActivity, MainActivity::class.java))
        finish()
    }

    private fun registerUser(userId: String) {
        //register user here
        startActivity(Intent(this@OtpActivity, MainActivity::class.java))
        finish()

    }


    private fun resendVerificationCode(
        phoneNumber: String,
        token: PhoneAuthProvider.ForceResendingToken
    ) {
        val options = PhoneAuthOptions.newBuilder(mAuth!!)
            .setPhoneNumber(phoneNumber) // Phone number to verify
            .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
            .setActivity(this) // Activity (for callback binding)
            .setCallbacks(mCallBack) // OnVerificationStateChangedCallbacks
            .setForceResendingToken(token) // ForceResendingToken from callbacks
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun validation(otp: String) {
        if (otp.isEmpty()) {
            showToast(resources.getString(R.string.enter_valid_otp))
            return
        }
        progressDialog = AppUtils.progressDialog(this@OtpActivity)
        verifyPhoneNumberWithCode(verificationid!!, otp)

    }
}