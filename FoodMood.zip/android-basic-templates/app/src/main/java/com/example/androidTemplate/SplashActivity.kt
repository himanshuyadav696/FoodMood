package com.example.androidTemplate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import com.example.androidTemplate.databinding.ActivitySplashBinding
import com.example.androidTemplate.ui.login.SignInActivity
import com.example.androidTemplate.ui.onboarding.OnboardingActivity
import com.example.androidTemplate.utils.AppConstants
import com.example.androidTemplate.utils.AppUtils

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        binding = DataBindingUtil.setContentView(this@SplashActivity, R.layout.activity_splash)
        checkForLogin()

    }

    private fun checkForLogin() {
        val isLoggedIn =
            AppUtils.getPrefBoolean(AppConstants.USER_PREF.IS_LOGIN, this@SplashActivity)
        Handler(mainLooper).postDelayed({
            if (isLoggedIn) {
                intent = Intent(this@SplashActivity, MainActivity::class.java)
            } else {
                intent = Intent(this@SplashActivity, OnboardingActivity::class.java)
            }
            startActivity(intent)
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }, 3000)
    }
}