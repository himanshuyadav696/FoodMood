package com.example.androidTemplate.core.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.FoodTypeLayoutBinding
import com.example.androidTemplate.ui.home.ItemsViewModel


class FoodListAdapter(val context: Context) :
    RecyclerView.Adapter<FoodListAdapter.ViewHolder>() {
    var resultList: List<ItemsViewModel>? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = DataBindingUtil.inflate<FoodTypeLayoutBinding>(
            layoutInflater,
            R.layout.food_type_layout,
            parent,
            false
        )
        return ViewHolder(binding)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(resultList!![position], position)

    }

    override fun getItemCount(): Int {
        if(resultList==null){
            return 0
        }else{
            return resultList!!.size
        }
    }

    inner class ViewHolder(val binding: FoodTypeLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(model:ItemsViewModel?,position: Int) {
            binding.apply {
                model?.image?.let { ivFoodType.setImageResource(it) }
                tvFoodName.text = model?.foodName
            }
        }
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    fun setData(it: List<ItemsViewModel>?) {
        resultList = it
        notifyDataSetChanged()
    }
}