package com.example.androidTemplate.core.adapter
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.NearbyMoodsLayoutBinding
import com.example.androidTemplate.ui.home.NearbyModel

class NearbyAdapter(val context: Context,val listner:ViewDetailClickListener) :
    RecyclerView.Adapter<NearbyAdapter.ViewHolder>() {
    var resultList: List<NearbyModel>? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = DataBindingUtil.inflate<NearbyMoodsLayoutBinding>(
            layoutInflater,
            R.layout.nearby_moods_layout,
            parent,
            false
        )
        return ViewHolder(binding)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(resultList!![position], position)

    }

    override fun getItemCount(): Int {
        if(resultList==null){
            return 0
        }else{
            return resultList!!.size
        }
    }

    inner class ViewHolder(val binding: NearbyMoodsLayoutBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(model: NearbyModel?, position: Int) {
            binding.apply {
                model?.image?.let { ivFoodType.setImageResource(it) }
                tvKitchenName.text = model?.restaurantsName
                tvNorthIndian.text = model?.food_type
                tvFoodName.text = model?.foodName
                tvPrice.text = model?.foodPrice
                tvPrice.text = model?.deliv_time

                ivFoodType.setOnClickListener {
                    if (model != null) {
                        listner.viewDetail(model,position, key = 1)
                    }
                }
                ivPlus.setOnClickListener {
                    if (model != null) {
                        listner.viewDetail(model,position, key = 2)
                    }
                }
            }
        }
    }

    fun setData(it: List<NearbyModel>?) {
        resultList = it
        notifyDataSetChanged()
    }

    interface ViewDetailClickListener {
        fun viewDetail(property: NearbyModel, position: Int,key:Int)
    }
}