package com.example.androidTemplate.ui.login

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.example.androidTemplate.R
import com.example.androidTemplate.databinding.FragmentRegisterBinding
import com.example.androidTemplate.utils.extensions.makeLinks


class RegisterFragment : Fragment() {
    private lateinit var binding: FragmentRegisterBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRegisterBinding.inflate(inflater)
        binding.lifecycleOwner = this
        binding.tvAllReadyAcc.makeLinks(
            Pair(getString(R.string.sign_in), View.OnClickListener {
                it.findNavController()
                    .navigate(RegisterFragmentDirections.actionMoveTobLoginFragment())

            }), isUnderLine = false
        )
        binding.btnBack.setOnClickListener {
            findNavController().popBackStack()
        }
        return binding.root
    }
}