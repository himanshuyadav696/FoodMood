package com.example.androidTemplate.data.sharedPrefs

import android.content.Context
import androidx.preference.PreferenceManager.getDefaultSharedPreferences

class PrefsHelper(context: Context) {
    /* Init sharedPreferences with injected context*/
    val sharedPref = getDefaultSharedPreferences(context)
    var token by PrefsStringDelegate(PrefKeys.USER_TOKEN)
    var isLoggedIn by PrefsBooleanDelegate(PrefKeys.IS_LOGIN)
    var isFirstTime by PrefsBooleanDelegate(PrefKeys.IS_FIRST_TIME)
}

object PrefKeys {
    const val IS_LOGIN = "UESR_iS_LOGIN"
    const val USER_TOKEN = "UESR_TOKEN"
    const val IS_FIRST_TIME = "IS_FIRST_TIME"

}
