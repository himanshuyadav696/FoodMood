package com.example.androidTemplate
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Base64.DEFAULT
import android.util.Base64.encodeToString
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.setupWithNavController
import com.example.androidTemplate.databinding.ActivityMainBinding
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException

class MainActivity : AppCompatActivity() {
    private var navController: NavController? = null
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView<ActivityMainBinding>(
            this@MainActivity,
            R.layout.activity_main
        )
        val navHostFragment = (supportFragmentManager
            .findFragmentById(R.id.navFragment)) as NavHostFragment?
        navController = navHostFragment?.findNavController()
        val bottomNavigationView = binding.appBarMain.bottomNav
        NavigationUI.setupWithNavController(
            bottomNavigationView,
            navHostFragment!!.navController
        )
        navController = navHostFragment.findNavController()
        appBarConfiguration = AppBarConfiguration(navController!!.graph, binding.drawerLayout)
        binding.appBarMain.bottomNav.setupWithNavController(navController!!)
        setUpNavigation()
        getFacebookHashKey()
    }

    private fun setUpNavigation() {
        binding.appBarMain.bottomNav.setOnNavigationItemSelectedListener { item: MenuItem? ->  // using lamda
            when (item?.itemId) {
                R.id.menuHome ->{
                    navController?.popBackStack()
                    navController?.navigate(R.id.homeFragment)
                }
                R.id.menuCategory ->{
                    navController?.popBackStack()
                    navController?.navigate(R.id.categoryFragment)
                }
                R.id.menuRestaurents ->{
                    navController?.popBackStack()
                    navController?.navigate(R.id.restaurantsFragment)
                }
                R.id.menuCart ->{
                    navController?.popBackStack()
                    navController?.navigate(R.id.cartFragment)
                }
                R.id.menuProfile ->{
                    navController?.popBackStack()
                    navController?.navigate(R.id.profileFragment)
                }
            }
            true

        }

    }

    fun hideBottomNav(){
        binding.appBarMain.bottomNav.visibility = View.GONE
    }
    fun showBottomNav(){
        binding.appBarMain.bottomNav.visibility = View.VISIBLE

    }
    override fun onSupportNavigateUp(): Boolean {
        val navController = Navigation.findNavController(this, R.id.navFragment)
        return navController.navigateUp() || super.onSupportNavigateUp()
    }

    //this function to print hashKey
    @SuppressLint("PackageManagerGetSignatures")
    private fun getFacebookHashKey(){
        try {
            val info =
                packageManager.getPackageInfo("com.app.temoCare", PackageManager.GET_SIGNATURES)
            for (signature in info.signatures) {
                val md: MessageDigest = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.d("KeyHash:", encodeToString(md.digest(),DEFAULT))
            }
        } catch (e: PackageManager.NameNotFoundException) {
            Log.e("KeyHash:", e.toString())
        } catch (e: NoSuchAlgorithmException) {
            Log.e("KeyHash:", e.toString())
        }
    }

}