package com.example.androidTemplate.ui.home
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.androidTemplate.R
import com.example.androidTemplate.core.adapter.FoodListAdapter
import com.example.androidTemplate.core.adapter.HomeViewpagerAdapter
import com.example.androidTemplate.core.adapter.NearbyAdapter
import com.example.androidTemplate.databinding.FragmentHomeBinding

class HomeFragment : Fragment(),NearbyAdapter.ViewDetailClickListener{
    private lateinit var binding:FragmentHomeBinding
    private lateinit var homeViewpagerAdapter: HomeViewpagerAdapter
    private lateinit var foodListAdapter: FoodListAdapter
    private lateinit var nearbyAdapter: NearbyAdapter
    private lateinit var imageList: List<Int>
    val foodlist = mutableListOf<ItemsViewModel>()
    val restaurantsList = mutableListOf<ItemsViewModel>()
    val nearbyList = mutableListOf<NearbyModel>()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(layoutInflater)
        viewPagerImages()
        rcvFoodType()
        rcvRestNearU()
        rcvNearbyMood()
        return binding.root
    }

    private fun rcvNearbyMood() {
        binding.rcvNearby.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.VERTICAL, false)
        nearbyAdapter = NearbyAdapter(requireContext(),this)
        binding.rcvNearby.adapter = nearbyAdapter
        for (i in 1..20) {
            nearbyList.add(
                NearbyModel(R.drawable.samosa,
                "Desi Kitchen$i",
            "North Indian$i",
            "Samosa+$i",
                    "₹ 50",
                "15min/1km",)
            )
        }
        nearbyAdapter.setData(nearbyList)
    }

    private fun rcvRestNearU() {
        binding.rcvRestaurants.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.HORIZONTAL, false)
        foodListAdapter = FoodListAdapter(requireContext())
        binding.rcvRestaurants.adapter = foodListAdapter
        for (i in 1..20) {
            restaurantsList.add(ItemsViewModel(R.drawable.samosa, "Item " + i))
        }
        foodListAdapter.setData(restaurantsList)
    }

    private fun rcvFoodType() {
        binding.rcvFoodType.layoutManager =
            LinearLayoutManager(requireActivity(), LinearLayoutManager.HORIZONTAL, false)
        foodListAdapter = FoodListAdapter(requireContext())
        binding.rcvFoodType.adapter = foodListAdapter
        foodlist.add(ItemsViewModel(R.drawable.samosa, "Snacks"))
        foodlist.add(ItemsViewModel(R.drawable.pizzaa, "Pizza's"))
        foodlist.add(ItemsViewModel(R.drawable.biryanni, "Biryani"))
        foodlist.add(ItemsViewModel(R.drawable.burger, "Burgers"))
        foodlist.add(ItemsViewModel(R.drawable.chineese, "Chinese"))
        foodlist.add(ItemsViewModel(R.drawable.sweets, "Sweets"))
        foodlist.add(ItemsViewModel(R.drawable.norther_indian, "North Indian"))
        foodListAdapter.setData(foodlist)
    }

    private fun viewPagerImages() {
        imageList = ArrayList<Int>()
        imageList = imageList + R.drawable.pager_image
        imageList = imageList + R.drawable.pager_image
        imageList = imageList + R.drawable.pager_image
        imageList = imageList + R.drawable.pager_image
        imageList = imageList + R.drawable.pager_image
        homeViewpagerAdapter = HomeViewpagerAdapter(requireActivity(), imageList)
        binding.viewPager.adapter = homeViewpagerAdapter
    }

    override fun viewDetail(property: NearbyModel, position: Int,key:Int) {
        if(key==1){
            findNavController().navigate(HomeFragmentDirections.actionHomeFragmentToBottomSheetFoodFragment())
        }
        if(key==2){
            findNavController().navigate(HomeFragmentDirections.actionHomeFragmentToAddcartBottomsheetFragment())
        }
    }

}
