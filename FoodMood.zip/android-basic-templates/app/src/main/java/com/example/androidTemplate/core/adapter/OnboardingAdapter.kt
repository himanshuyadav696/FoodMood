package com.example.androidTemplate.core.adapter
import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.androidTemplate.R
import com.example.androidTemplate.ui.onboarding.OnboardingFirstFragment

class OnboardingAdapter (
    fragmentActivity: FragmentActivity,
    private val context: Context
) :
    FragmentStateAdapter(fragmentActivity) {

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> OnboardingFirstFragment.newInstance(
                context.resources.getString(R.string.title_onboarding_1),
                context.resources.getString(R.string.description_onboarding_1),
                R.drawable.ic_intro_first
            )
            1 -> OnboardingFirstFragment.newInstance(
                context.resources.getString(R.string.title_onboarding_2),
                context.resources.getString(R.string.description_onboarding_2),
                R.drawable.ic_onboard_two
            )
            2 -> OnboardingFirstFragment.newInstance(
                context.resources.getString(R.string.title_onboarding_2),
                context.resources.getString(R.string.description_onboarding_2),
                R.drawable.ic_onboard_two
            )
            else -> OnboardingFirstFragment.newInstance(
                context.resources.getString(R.string.title_onboarding_4),
                context.resources.getString(R.string.description_onboarding_4),
                R.drawable.ic_onboard_four
            )
        }
    }

    override fun getItemCount(): Int {
        return 4
    }
}